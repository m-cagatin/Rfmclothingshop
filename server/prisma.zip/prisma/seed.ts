import 'dotenv/config';
import argon2 from 'argon2';
import { PrismaClient } from '@prisma/client';
import { randomBytes } from 'crypto';

const prisma = new PrismaClient();

function generateId() {
  return randomBytes(16).toString('hex');
}

async function main() {
  const adminEmail = 'admin@rfm.com';
  const demoEmail = 'test@rfm.com';
  
  // Delete existing admin if corrupted
  await prisma.user.deleteMany({ where: { email: adminEmail } });
  console.log('Cleaned up existing admin user');

  // Delete existing demo customer if corrupted
  await prisma.user.deleteMany({ where: { email: demoEmail } });
  console.log('Cleaned up existing demo customer');

  const adminPasswordHash = await argon2.hash('admin123');
  const demoPasswordHash = await argon2.hash('password123');

  await prisma.user.create({
    data: {
      id: generateId(),
      name: 'Admin User',
      email: adminEmail,
      passwordHash: adminPasswordHash,
      role: 'admin',
      emailVerified: true,
    },
  });

  await prisma.user.create({
    data: {
      id: generateId(),
      name: 'Demo Customer',
      email: demoEmail,
      passwordHash: demoPasswordHash,
      role: 'customer',
      emailVerified: true,
    },
  });

  console.log('✅ Seeded admin user: admin@rfm.com / admin123');
  console.log('✅ Seeded demo customer: test@rfm.com / password123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
